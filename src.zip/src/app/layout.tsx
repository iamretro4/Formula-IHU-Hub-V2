import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Sidebar from "@/components/Sidebar";
import { SupabaseProvider } from "@supabase/auth-helpers-react"; // Import the provider!
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});
const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});
export const metadata: Metadata = {
  title: "Formula IHU Competition Hub",
  description: "All-in-one portal for Formula Student Greece",
};
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased flex min-h-screen bg-neutral-50 dark:bg-neutral-950`}
      >
        <SupabaseProvider> {/* Wrap everything in the provider */}
          <Sidebar />
          <main className="flex-1 min-h-screen">{children}</main>
        </SupabaseProvider>
      </body>
    </html>
  );
}
